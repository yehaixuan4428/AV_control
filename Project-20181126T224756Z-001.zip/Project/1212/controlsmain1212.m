%% Part one
clear all;close all;clc;
x0 = [287;5;-176;0;2;0];
load ROB599_ControlsProject_part1_Team26.mat
[Y]=forwardIntegrateControlInput(ROB599_ControlsProject_part1_input,x0); 
checkTrajectory([Y(:,1),Y(:,3)],ROB599_ControlsProject_part1_input)


%% Part two
clc;clear all;
load TestTrack
Nobs=20;
Xobs= generateRandomObstacles(Nobs);

tic
in = ROB599_ControlsProject_part2_Team26(TestTrack,Xobs);
toc

x0 = [287;5;-176;0;2;0];
[Y]=forwardIntegrateControlInput(in,x0); 
checkTrajectory([Y(:,1),Y(:,3)],in,Xobs,TestTrack)


% Plotting Results
figure;hold on
for ii = 1:Nobs

    ob = Xobs{ii};
    ob = [ob;ob(1,:)];
    plot(ob(:,1),ob(:,2),'k-');
end
plot(TestTrack.bl(1,:),TestTrack.bl(2,:),'k');
plot(TestTrack.br(1,:),TestTrack.br(2,:),'k');
plot(Y(:,1),Y(:,3), 'r*','MarkerSize', 2);

% plot(path(1,:),path(2,:), 'g*','MarkerSize', 2);
% plot(traj(:,1),traj(:,3), 'b*','MarkerSize', 2);
axis equal;grid on;
% figure;hold on;
% plot(traj(:,2));
%%
figure;hold on;
plot(traj(:,1),traj(:,3), 'b*','MarkerSize', 2);
plot(Y(:,1),Y(:,3), 'r*','MarkerSize', 2);
