%function [input,traj] = pcontroller(path,x0,TestTrack,path_heading,tstep,u_nom)
W=13720;
Nw=2;
f=0.01;
Iz=2667;
a=1.35;
b=1.45;
By=0.27;
Cy=1.2;
Dy=2921;
Ey=-1.6;
Shy=0;
Svy=0;
m=1400;

u_nom = 5;
x0 = [287;5;-176;0;2;0];
dist = [0,sqrt(diff(path(2,:)).^2+diff(path(1,:)).^2)];dist(1:15)=[];
path_heading = [0,atan2(diff(path(2,:)),diff(path(1,:)))];path_heading(1:15)=[];
tstep = round(dist./u_nom.*100);
N = sum(tstep);


K_deltaf = 1.2;  %0.275
K_Fx = 6000;
K_x=0.015;
traj = x0';
input = [];
for i = 2:12180
    psi_current = traj(end,5);
    psi_desired = path_heading(i);
    psi_diff = psi_desired-psi_current;
    deltaf = K_deltaf * psi_diff;

    x_current = traj(end,1);
    x_desired = path(1,i);
    x_diff = x_desired-x_current;
    y_current = traj(end,3);
    y_desired = path(2,i);
    y_diff = y_desired-y_current;
    indd=dsearchn(path',[x_current,y_current]);
    ppath = path(:,indd-1:indd+1);
    indd=dsearchn(TestTrack.bl',[x_current,y_current]);
    if indd == 1;
        indd = 2;
    end
    lbound = TestTrack.bl(:,indd-1:indd+1);
    pgonx = [ppath lbound];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left=inpolygon(x_current,y_current,pgonx(1,k)',pgonx(2,k)');
    if is_left == 1
        deltaf = deltaf-K_x*norm([x_diff;y_diff]);
    else
        deltaf = deltaf+K_x*norm([x_diff;y_diff]);
    end
    if deltaf > 0.35
        deltaf = 0.35;
    end
    if deltaf < -0.35
        deltaf = -0.35;
    end

   
    u_current = traj(end,2);
    u_desired = u_nom;
    u_diff = u_desired-u_current;
    Fx = K_Fx * u_diff;
    if Fx > 1000
        Fx = 1000;
    end
    if Fx < 0
        Fx = 0;
    end
    
    
    nn = tstep(i);
    if i>2
        nn = nn+1;
    end
    input_add = [deltaf*ones(nn,1),Fx*ones(nn,1)];
    
    T=0:0.01:(nn-1)*0.01;
    
    %slip angle functions in degrees
    a_f=@(t,x) rad2deg(deltaf-atan2(x(4)+a*x(6),x(2)));
    a_r=@(t,x) rad2deg(-atan2((x(4)-b*x(6)),x(2)));

    %Nonlinear Tire Dynamics
    phi_yf=@(t,x) (1-Ey)*(a_f(t,x)+Shy)+(Ey/By)*atan(By*(a_f(t,x)+Shy));
    phi_yr=@(t,x) (1-Ey)*(a_r(t,x)+Shy)+(Ey/By)*atan(By*(a_r(t,x)+Shy));

    F_yf=@(t,x) Dy*sin(Cy*atan(By*phi_yf(t,x)))+Svy;
    F_yr=@(t,x) Dy*sin(Cy*atan(By*phi_yr(t,x)))+Svy;

    %vehicle dynamics
    df=@(t,x) [x(2)*cos(x(5))-x(4)*sin(x(5));...
            (-f*W+Nw*Fx-F_yf(t,x)*sin(deltaf))/m+x(4)*x(6);...
            x(2)*sin(x(5))+x(4)*cos(x(5));...
            (F_yf(t,x)*cos(deltaf)+F_yr(t,x))/m-x(2)*x(6);...
            x(6);...
            (F_yf(t,x)*a*cos(deltaf)-F_yr(t,x)*b)/Iz];
      
    %Solve for trajectory      
    [~,traj_add]=ode45(df,T,traj(end,:));
    if nn == 2
        traj = [traj;traj_add(end,:)];
    else
        traj = [traj;traj_add(2:end,:)];
    end
    
    
    input =[input;input_add(2:end,:)];
end
% figure;hold on
% for ii = 1:Nobs
%     ob = Xobs{ii};
%     ob = [ob;ob(1,:)];
%     plot(ob(:,1),ob(:,2),'k-');
% end
% plot(TestTrack.bl(1,:),TestTrack.bl(2,:),'k');
% plot(TestTrack.br(1,:),TestTrack.br(2,:),'k');
% plot(path(1,:),path(2,:), 'g*','MarkerSize', 3);
% plot(traj(:,1),traj(:,3), 'b*','MarkerSize', 3);
% 
% axis equal;grid on;
% figure;plot(traj(:,2))
% %end
