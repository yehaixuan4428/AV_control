%clean up
clc
clear all
close all

load TestTrack
Nobs=10;
Xobs= generateRandomObstacles(Nobs);
[path,theta] = gen_traj(Xobs,TestTrack);



function [traj,theta_traj] = gen_traj(Xobs,TestTrack)
%populate random obstacles
Xobs = cell2mat(Xobs);
Nobs=size(Xobs,2)/2;

%calculate obstacle centers and corners
for i = 1:Nobs
    Xobs_ctr(i,1) = mean(Xobs(:,2*i-1));
    Xobs_ctr(i,2) = mean(Xobs(:,2*i));
    Xobs_x(4*i-3:4*i,1) = Xobs(:,2*i-1);
    Xobs_y(4*i-3:4*i,1) = Xobs(:,2*i);
end

%see which side of track the obstacle is on
[ind_l, ind_r] = obs_side(Nobs,Xobs_ctr, TestTrack);

left_obs = Xobs_ctr(ind_l,:);
right_obs = Xobs_ctr(ind_r,:);



%get a line between left boundary and centerline
l_cline=(TestTrack.bl+TestTrack.cline)./2;

%get a line between right boundary and centerline
r_cline=(TestTrack.br+TestTrack.cline)./2;

%expand sampling rate of center line and test track boundary
scale = 50;
bl_x=interp(TestTrack.bl(1,:),scale);
bl_y=interp(TestTrack.bl(2,:),scale);
br_x=interp(TestTrack.br(1,:),scale);
br_y=interp(TestTrack.br(2,:),scale);
cline_x=interp(TestTrack.cline(1,:),scale);
cline_y=interp(TestTrack.cline(2,:),scale);
rcline_y=interp(r_cline(2,:),scale);
rcline_x=interp(r_cline(1,:),scale);
lcline_y=interp(l_cline(2,:),scale);
lcline_x=interp(l_cline(1,:),scale);
r_cline=[rcline_x ;rcline_y];
l_cline=[lcline_x ;lcline_y];

%lets make convexhull of obstacles and check if centerline goes through it
is_coll=zeros(size(cline_x,2),25);
is_coll_obs=zeros(size(cline_x,2),25);
for i=1:Nobs
    pgonx = 1.3*[Xobs(:,2*i-1)-mean(Xobs(:,2*i-1)) Xobs(:,2*i)-mean(Xobs(:,2*i))];
    pgonx=[pgonx(:,1)+mean(Xobs(:,2*i-1)) pgonx(:,2)+mean(Xobs(:,2*i))];
    k=convhull(pgonx(:,1),pgonx(:,2));
    for j =1:size(cline_x,2)
        is_coll(j,i)=inpolygon(cline_x(j),cline_y(j),pgonx(k,1),pgonx(k,2));
        if is_coll(j,i)
            is_coll_obs(j,i) = i;
        end
        
    end


end
is_coll_all=sum(is_coll,2);
is_coll_obs_all=sum(is_coll_obs,2);




%now replace colliding centerline points with a new center line on open
%track side
traj=[cline_x;cline_y];
side = zeros(1,size(cline_x,2));
for i=1:size(is_coll_obs_all,1)
    if ismember(is_coll_obs_all(i),ind_l)
        traj(:,i) = r_cline(:,i);
        side(i) = 1;
    elseif ismember(is_coll_obs_all(i),ind_r)
        traj(:,i) = l_cline(:,i);
        side(i) = 2;
    end
end


%find loc corresponding to front of obs
f_corner = zeros(4,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i-1) ==0))
        f_corner(1:2,l) = traj(:,i);
        f_corner(3,l) = i;
        f_corner(4,l) = side(i);
        l=l+1;
    end
end

%find loc corresponding to back of obs
b_corner = zeros(3,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i+1) ==0))
        b_corner(1:2,l) = traj(:,i);
        b_corner(3,l) = i;
        b_corner(4,l) = side(i);
        l=l+1;
    end
end

%smoothing to stay on same side of track if consecutive objects are on same 
%side of track
for i =1:Nobs-1
    %check if the next obstacle is on the same side of the track
    if (b_corner(4,i) == f_corner(4,i+1))
        if(b_corner(4,i) == 1) 
            traj(1,b_corner(3,i):f_corner(3,i+1))= r_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= r_cline(2,b_corner(3,i):f_corner(3,i+1));
        else
            traj(1,b_corner(3,i):f_corner(3,i+1))= l_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= l_cline(2,b_corner(3,i):f_corner(3,i+1));
        end
    %if it is a spot that transitions sides, ramp to other side over a
    %distance of 10 meters
    else
        %compute distance of each point on traj to next obs
          
        if(b_corner(4,i) == 1) 
            dist = 0;
            dist_ind = b_corner(3,i);
            dist_ramp=20;
            dist_obs = sqrt( (b_corner(1,i)-f_corner(1,i+1))^2 + (b_corner(2,i)-f_corner(2,i+1))^2 );
            if (dist_obs<=20)
                dist_ramp=dist_obs;
            end
            while(dist<=dist_ramp)
                dist_ind = dist_ind+1;
                dist = sqrt( (b_corner(1,i)-l_cline(1,dist_ind))^2 + (b_corner(2,i)-l_cline(2,dist_ind))^2 );
            end  
            dist_ind = dist_ind-1;
            traj(1,b_corner(3,i):dist_ind)=linspace(b_corner(1,i),l_cline(1,dist_ind), dist_ind+1-b_corner(3,i));
            traj(1,dist_ind:f_corner(3,i+1)) = l_cline(1, dist_ind:f_corner(3,i+1));
            traj(2,b_corner(3,i):dist_ind)=linspace(b_corner(2,i),l_cline(2,dist_ind), dist_ind+1-b_corner(3,i));
            traj(2,dist_ind:f_corner(3,i+1)) = l_cline(2, dist_ind:f_corner(3,i+1));
        else
            dist = 0;
            dist_ind = b_corner(3,i);
            dist_ramp=20;
            dist_obs = sqrt( (b_corner(1,i)-f_corner(1,i+1))^2 + (b_corner(2,i)-f_corner(2,i+1))^2 );
            if (dist_obs<=20)
                dist_ramp=dist_obs;
            end
            while(dist<=dist_ramp)
                dist_ind = dist_ind+1;
                dist = sqrt( (b_corner(1,i)-r_cline(1,dist_ind))^2 + (b_corner(2,i)-r_cline(2,dist_ind))^2 );
            end  
            dist_ind = dist_ind-1;
            traj(1,b_corner(3,i):dist_ind)=linspace(b_corner(1,i),r_cline(1,dist_ind), dist_ind+1-b_corner(3,i));
            traj(1,dist_ind:f_corner(3,i+1)) = r_cline(1, dist_ind:f_corner(3,i+1));
            traj(2,b_corner(3,i):dist_ind)=linspace(b_corner(2,i),r_cline(2,dist_ind), dist_ind+1-b_corner(3,i));
            traj(2,dist_ind:f_corner(3,i+1)) = r_cline(2, dist_ind:f_corner(3,i+1));
        end
    end
end

%ramp into first obstacle
for j=1:f_corner(3,1)-1
        %compute distance of each point on traj to next obs
        dist = sqrt( (f_corner(1,1)-traj(1,j))^2 + (f_corner(2,1)-traj(2,j))^2 );
        if dist<=10.0
            traj_left_edge(:,1) = [traj(:,j);j];
            break;
        end
    end 
traj(1,traj_left_edge(3,1):f_corner(3,1))=linspace(traj_left_edge(1,1), f_corner(1,1), -traj_left_edge(3,1)+1+f_corner(3,1));
traj(2,traj_left_edge(3,1):f_corner(3,1))=linspace(traj_left_edge(2,1), f_corner(2,1), -traj_left_edge(3,1)+1+f_corner(3,1));


%ramp off last obstacle
for j=size(traj,2)-1:-1:b_corner(3,i)+1
        
    %compute distance of each point on traj to next obs
    dist = sqrt( (b_corner(1,Nobs)-traj(1,j))^2 + (b_corner(2,Nobs)-traj(2,j))^2 );
   
    if dist<=10.0
       traj_b_edge(:,Nobs) = [traj(:,j);j];
       break;
    end
end

traj(1,b_corner(3,Nobs):traj_b_edge(3,Nobs))=linspace(b_corner(1,Nobs),traj_b_edge(1,Nobs), traj_b_edge(3,Nobs)+1-b_corner(3,Nobs));
traj(2,b_corner(3,Nobs):traj_b_edge(3,Nobs))=linspace(b_corner(2,Nobs),traj_b_edge(2,Nobs), traj_b_edge(3,Nobs)+1-b_corner(3,Nobs));


%now we calculate the heading of the trajectory in radians
for t=1:size(traj,2)-1
    slope = (traj(2,t)-traj(2,t+1))  / (traj(1,t)-traj(1,t+1));
    theta_traj(t+1) = atan(slope);
    if theta_traj(t+1)<0
        theta_traj(t+1)=theta_traj(t+1)+pi;
    end
        
end
theta_traj(1)=theta_traj(2);




end



function [ind_l, ind_r] = obs_side(Nobs,Xobs_ctr,TestTrack)

% find three close points on centerline to obstacle center
ctr_close_ind=dsearchn(TestTrack.cline',Xobs_ctr);
for i=1:size(ctr_close_ind)
    ctr_close_loc(:,3*i-2:3*i) = TestTrack.cline(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

%find three close points on left track boundary
bl_close_ind=dsearchn(TestTrack.bl',Xobs_ctr);
for i=1:size(ctr_close_ind)
    bl_close_loc(:,3*i-2:3*i) = TestTrack.bl(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

% check if obstacle lies inside of a box formed by left boundary and
% centerine
is_left=zeros(Nobs,1);
for i=1:Nobs
    pgonx = [ctr_close_loc(:,3*i-2:3*i) bl_close_loc(:,3*i-2:3*i);];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left(i)=inpolygon(Xobs_ctr(i,1),Xobs_ctr(i,2),pgonx(1,k)',pgonx(2,k)');

end

%save left and right obstacles in seperate arrays
 ind_l = find(is_left(:)==1);
 ind_r = find(is_left(:)==0);
end