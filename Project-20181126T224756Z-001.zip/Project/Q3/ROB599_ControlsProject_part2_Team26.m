function input = ROB599_ControlsProject_part2_Team26(TestTrack,Xobs)
% LOG
% aaa=12; ccc=1000; bbb=1; K_deltaf=0.945; K_Fx=2900; K_x=0.012;  %best
% aaa=10; ccc=1200; bbb=1; K_deltaf=0.945; K_Fx = 3000; K_x=0.012; 

% aaa=15; ccc=800; bbb=0; K_deltaf=0.7650; K_Fx = 2150; K_x=0.00588;
% aaa=20; ccc=600; bbb=0; K_deltaf=0.410; K_Fx = 1780; K_x=0.00500;
% aaa=4; ccc=3000; bbb=3; K_deltaf=1.15; K_Fx = 6000; K_x=0.015;       
% aaa=2; ccc=6000; bbb=7; K_deltaf=1.15; K_Fx = 6000; K_x=0.015;       
% aaa=40; ccc=285; bbb=1; K_deltaf=0.338650; K_Fx = 1270; K_x=0.000730; 

aaa = 12;bbb = 1;ccc=1000; K_deltaf=0.945; K_Fx=2900; K_x=0.012;
updates = [80:80:800,1000000000];jj = 1;

[path,theta] = gen_traj(Xobs,TestTrack);
path = path(:,1:aaa:end); % Sample path every aaa points

%%%%%%%%%%%%%%%% start PID Controls part%%%%%%%%%%
W=13720;
Nw=2;
f=0.01;
Iz=2667;
a=1.35;
b=1.45;
By=0.27;
Cy=1.2;
Dy=2921;
Ey=-1.6;
Shy=0;
Svy=0;
m=1400;

u_nom = 5;
x0 = [287;5;-176;0;2;0];
dist = [0,sqrt(diff(path(2,:)).^2+diff(path(1,:)).^2)];dist(1:bbb)=[];
path_heading = [0,atan2(diff(path(2,:)),diff(path(1,:)))];path_heading(1:bbb)=[];
tstep = round(dist./u_nom.*100);
N = sum(tstep);


traj = x0';
input = [];
for i = 2:length(tstep)  
    psi_current = traj(end,5);
    psi_desired = path_heading(i);
    psi_diff = psi_desired-psi_current;
    deltaf = K_deltaf * psi_diff;

    x_current = traj(end,1);
    x_desired = path(1,i);
    x_diff = x_desired-x_current;
    y_current = traj(end,3);
    y_desired = path(2,i);
    y_diff = y_desired-y_current;
    
    indd=dsearchn(path',[x_current,y_current]);
    if indd == 1;
        indd = 2;
    end
    if indd == size(path,2);
        indd = size(path,2)-1;
    end
    ppath = path(:,indd-1:indd+1);
    indd=dsearchn(TestTrack.bl',[x_current,y_current]);
    if indd == 1;
        indd = 2;
    end
    if indd == 246;
        indd = 245;
    end
    lbound = TestTrack.bl(:,indd-1:indd+1);
    pgonx = [ppath lbound];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left=inpolygon(x_current,y_current,pgonx(1,k)',pgonx(2,k)');
    if is_left == 1
        deltaf = deltaf-K_x*norm([x_diff;y_diff]);
    else
        deltaf = deltaf+K_x*norm([x_diff;y_diff]);
    end
    
    if deltaf > 0.30
        deltaf = 0.30;
    end
    if deltaf < -0.30
        deltaf = -0.30;
    end

    u_current = traj(end,2);
    u_desired = u_nom;
    u_diff = u_desired-u_current;
    Fx = K_Fx * u_diff;
    if Fx > 600
        Fx = 600;
    end
    if Fx < 0
        Fx = 0;
    end
    
    nn = tstep(i);
    if i>2
        nn = nn+1;
    end
    input_add = [deltaf*ones(nn,1),Fx*ones(nn,1)];
    
    T=0:0.01:(nn-1)*0.01;
    
    %slip angle functions in degrees
    a_f=@(t,x) rad2deg(deltaf-atan2(x(4)+a*x(6),x(2)));
    a_r=@(t,x) rad2deg(-atan2((x(4)-b*x(6)),x(2)));

    %Nonlinear Tire Dynamics
    phi_yf=@(t,x) (1-Ey)*(a_f(t,x)+Shy)+(Ey/By)*atan(By*(a_f(t,x)+Shy));
    phi_yr=@(t,x) (1-Ey)*(a_r(t,x)+Shy)+(Ey/By)*atan(By*(a_r(t,x)+Shy));

    F_yf=@(t,x) Dy*sin(Cy*atan(By*phi_yf(t,x)))+Svy;
    F_yr=@(t,x) Dy*sin(Cy*atan(By*phi_yr(t,x)))+Svy;

    %vehicle dynamics
    df=@(t,x) [x(2)*cos(x(5))-x(4)*sin(x(5));...
            (-f*W+Nw*Fx-F_yf(t,x)*sin(deltaf))/m+x(4)*x(6);...
            x(2)*sin(x(5))+x(4)*cos(x(5));...
            (F_yf(t,x)*cos(deltaf)+F_yr(t,x))/m-x(2)*x(6);...
            x(6);...
            (F_yf(t,x)*a*cos(deltaf)-F_yr(t,x)*b)/Iz];
      
    %Solve for trajectory      
    [~,traj_add]=ode45(df,T,traj(end,:));
    traj = [traj;traj_add(2:end,:)];
    input =[input;input_add(2:end,:)];
    
%     Update to minimize integration error
    if i > updates(jj)
        TTT = 0:0.01:(size(input,1)-1)*0.01;
        d_fff = @(t) interp1(TTT,input(:,1),t,'previous','extrap') ;
        F_xxx = @(t) interp1(TTT,input(:,2),t,'previous','extrap') ;

        % slip angle functions in degrees
        a_fff = @(t,x) rad2deg(d_fff(t)-atan2(x(4)+a*x(6),x(2))) ;
        a_rrr = @(t,x) rad2deg(-atan2((x(4)-b*x(6)),x(2))) ;

        % Nonlinear Tire Dynamics
        phi_yfff = @(t,x) (1-Ey)*(a_fff(t,x)+Shy)+(Ey/By)*atan(By*(a_fff(t,x)+Shy)) ;
        phi_yrrr = @(t,x) (1-Ey)*(a_rrr(t,x)+Shy)+(Ey/By)*atan(By*(a_rrr(t,x)+Shy)) ;

        F_yfff = @(t,x) Dy*sin(Cy*atan(By*phi_yfff(t,x)))+Svy ;
        F_yrrr = @(t,x) Dy*sin(Cy*atan(By*phi_yrrr(t,x)))+Svy ;

        % vehicle dynamics
        dfff = @(t,x) [x(2)*cos(x(5))-x(4)*sin(x(5)) ;...
                  (-f*W+Nw*F_xxx(t)-F_yfff(t,x)*sin(d_fff(t)))/m+x(4)*x(6) ;...
                  x(2)*sin(x(5))+x(4)*cos(x(5)) ;...
                  (F_yfff(t,x)*cos(d_fff(t))+F_yrrr(t,x))/m-x(2)*x(6) ;...
                  x(6) ;...
                  (F_yfff(t,x)*a*cos(d_fff(t))-F_yrrr(t,x)*b)/Iz] ;

        % Solve for trajectory
        [~,traj] = ode45(dfff,TTT,x0) ;
        jj = jj+1;
    end
         
end

% To finish whatever is left
input = [input;[zeros(100,1),5000*ones(100,1)]];
end


function [ind_l, ind_r] = obs_side(Nobs,Xobs_ctr,TestTrack)
% find three close points on centerline to obstacle center
ctr_close_ind=dsearchn(TestTrack.cline',Xobs_ctr);
for i=1:size(ctr_close_ind)
    ctr_close_loc(:,3*i-2:3*i) = TestTrack.cline(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

%find three close points on left track boundary
bl_close_ind=dsearchn(TestTrack.bl',Xobs_ctr);
for i=1:size(ctr_close_ind)
    bl_close_loc(:,3*i-2:3*i) = TestTrack.bl(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

% check if obstacle lies inside of a box formed by left boundary and
% centerine
is_left=zeros(Nobs,1);
for i=1:Nobs
    pgonx = [ctr_close_loc(:,3*i-2:3*i) bl_close_loc(:,3*i-2:3*i);];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left(i)=inpolygon(Xobs_ctr(i,1),Xobs_ctr(i,2),pgonx(1,k)',pgonx(2,k)');

end

%save left and right obstacles in seperate arrays
 ind_l = find(is_left(:)==1);
 ind_r = find(is_left(:)==0);
end


function [traj,theta_traj] = gen_traj(Xobs,TestTrack)
%populate random obstacles
Xobs = cell2mat(Xobs);
Nobs=size(Xobs,2)/2;

%calculate obstacle centers and corners
for i = 1:Nobs
    Xobs_ctr(i,1) = mean(Xobs(:,2*i-1));
    Xobs_ctr(i,2) = mean(Xobs(:,2*i));
    Xobs_x(4*i-3:4*i,1) = Xobs(:,2*i-1);
    Xobs_y(4*i-3:4*i,1) = Xobs(:,2*i);
end

%see which side of track the obstacle is on
[ind_l, ind_r] = obs_side(Nobs,Xobs_ctr, TestTrack);


left_obs = Xobs_ctr(ind_l,:);
right_obs = Xobs_ctr(ind_r,:);



%get a line between left boundary and centerline
l_cline=(TestTrack.bl+TestTrack.cline)./2;

%get a line between right boundary and centerline
r_cline=(TestTrack.br+TestTrack.cline)./2;

%expand sampling rate of center line and test track boundary
scale = 50;
bl_x=interp(TestTrack.bl(1,:),scale);
bl_y=interp(TestTrack.bl(2,:),scale);
br_x=interp(TestTrack.br(1,:),scale);
br_y=interp(TestTrack.br(2,:),scale);
cline_x=interp(TestTrack.cline(1,:),scale);
cline_y=interp(TestTrack.cline(2,:),scale);
rcline_y=interp(r_cline(2,:),scale);
rcline_x=interp(r_cline(1,:),scale);
lcline_y=interp(l_cline(2,:),scale);
lcline_x=interp(l_cline(1,:),scale);
r_cline=[rcline_x ;rcline_y];
l_cline=[lcline_x ;lcline_y];

%lets make convexhull of obstacles and check if centerline goes through it
is_coll=zeros(size(cline_x,2),25);
is_coll_obs=zeros(size(cline_x,2),25);
for i=1:Nobs
    pgonx = 1.3*[Xobs(:,2*i-1)-mean(Xobs(:,2*i-1)) Xobs(:,2*i)-mean(Xobs(:,2*i))];
    pgonx=[pgonx(:,1)+mean(Xobs(:,2*i-1)) pgonx(:,2)+mean(Xobs(:,2*i))];
    k=convhull(pgonx(:,1),pgonx(:,2));
    for j =1:size(cline_x,2)
        is_coll(j,i)=inpolygon(cline_x(j),cline_y(j),pgonx(k,1),pgonx(k,2));
        if is_coll(j,i)
            is_coll_obs(j,i) = i;
        end
        
    end


end
is_coll_all=sum(is_coll,2);
is_coll_obs_all=sum(is_coll_obs,2);




%now replace colliding centerline points with a new center line on open
%track side
traj=[cline_x;cline_y];
side = zeros(1,size(cline_x,2));
for i=1:size(is_coll_obs_all,1)
    if ismember(is_coll_obs_all(i),ind_l)
        traj(:,i) = r_cline(:,i);
        side(i) = 1;
    elseif ismember(is_coll_obs_all(i),ind_r)
        traj(:,i) = l_cline(:,i);
        side(i) = 2;
    end
end


%find loc corresponding to front of obs
f_corner = zeros(4,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i-1) ==0))
        f_corner(1:2,l) = traj(:,i);
        f_corner(3,l) = i;
        f_corner(4,l) = side(i);
        l=l+1;
    end
end

%find loc corresponding to back of obs
b_corner = zeros(3,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i+1) ==0))
        b_corner(1:2,l) = traj(:,i);
        b_corner(3,l) = i;
        b_corner(4,l) = side(i);
        l=l+1;
    end
end

%smoothing to stay on same side of track if consecutive objects are on same 
%side of track
for i =1:Nobs-1
    %check if the next obstacle is on the same side of the track
    if (b_corner(4,i) == f_corner(4,i+1))
        if(b_corner(4,i) == 1) 
            traj(1,b_corner(3,i):f_corner(3,i+1))= r_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= r_cline(2,b_corner(3,i):f_corner(3,i+1));
        else
            traj(1,b_corner(3,i):f_corner(3,i+1))= l_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= l_cline(2,b_corner(3,i):f_corner(3,i+1));
        end
    %if it is a spot that transitions sides, ramp to other side over a
    %distance of 10 meters
    else
        %compute distance of each point on traj to next obs
          
        if(b_corner(4,i) == 1) 
            dist = 0;
            dist_ind = b_corner(3,i);
            dist_ramp=20;
            dist_obs = sqrt( (b_corner(1,i)-f_corner(1,i+1))^2 + (b_corner(2,i)-f_corner(2,i+1))^2 );
            if (dist_obs<=20)
                dist_ramp=dist_obs;
            end
            while(dist<=dist_ramp)
                dist_ind = dist_ind+1;
                dist = sqrt( (b_corner(1,i)-l_cline(1,dist_ind))^2 + (b_corner(2,i)-l_cline(2,dist_ind))^2 );
            end  
            dist_ind = dist_ind-1;
            traj(1,b_corner(3,i):dist_ind)=linspace(b_corner(1,i),l_cline(1,dist_ind), dist_ind+1-b_corner(3,i));
            traj(1,dist_ind:f_corner(3,i+1)) = l_cline(1, dist_ind:f_corner(3,i+1));
            traj(2,b_corner(3,i):dist_ind)=linspace(b_corner(2,i),l_cline(2,dist_ind), dist_ind+1-b_corner(3,i));
            traj(2,dist_ind:f_corner(3,i+1)) = l_cline(2, dist_ind:f_corner(3,i+1));
        else
            dist = 0;
            dist_ind = b_corner(3,i);
            dist_ramp=20;
            dist_obs = sqrt( (b_corner(1,i)-f_corner(1,i+1))^2 + (b_corner(2,i)-f_corner(2,i+1))^2 );
            if (dist_obs<=20)
                dist_ramp=dist_obs;
            end
            while(dist<=dist_ramp)
                dist_ind = dist_ind+1;
                dist = sqrt( (b_corner(1,i)-r_cline(1,dist_ind))^2 + (b_corner(2,i)-r_cline(2,dist_ind))^2 );
            end  
            dist_ind = dist_ind-1;
            traj(1,b_corner(3,i):dist_ind)=linspace(b_corner(1,i),r_cline(1,dist_ind), dist_ind+1-b_corner(3,i));
            traj(1,dist_ind:f_corner(3,i+1)) = r_cline(1, dist_ind:f_corner(3,i+1));
            traj(2,b_corner(3,i):dist_ind)=linspace(b_corner(2,i),r_cline(2,dist_ind), dist_ind+1-b_corner(3,i));
            traj(2,dist_ind:f_corner(3,i+1)) = r_cline(2, dist_ind:f_corner(3,i+1));
        end
    end
end

%ramp into first obstacle
for j=1:f_corner(3,1)-1
        %compute distance of each point on traj to next obs
        dist = sqrt( (f_corner(1,1)-traj(1,j))^2 + (f_corner(2,1)-traj(2,j))^2 );
        if dist<=10.0
            traj_left_edge(:,1) = [traj(:,j);j];
            break;
        end
    end 
traj(1,traj_left_edge(3,1):f_corner(3,1))=linspace(traj_left_edge(1,1), f_corner(1,1), -traj_left_edge(3,1)+1+f_corner(3,1));
traj(2,traj_left_edge(3,1):f_corner(3,1))=linspace(traj_left_edge(2,1), f_corner(2,1), -traj_left_edge(3,1)+1+f_corner(3,1));


%ramp off last obstacle
for j=size(traj,2)-1:-1:b_corner(3,i)+1
        
    %compute distance of each point on traj to next obs
    dist = sqrt( (b_corner(1,Nobs)-traj(1,j))^2 + (b_corner(2,Nobs)-traj(2,j))^2 );
   
    if dist<=10.0
       traj_b_edge(:,Nobs) = [traj(:,j);j];
       break;
    end
end

traj(1,b_corner(3,Nobs):traj_b_edge(3,Nobs))=linspace(b_corner(1,Nobs),traj_b_edge(1,Nobs), traj_b_edge(3,Nobs)+1-b_corner(3,Nobs));
traj(2,b_corner(3,Nobs):traj_b_edge(3,Nobs))=linspace(b_corner(2,Nobs),traj_b_edge(2,Nobs), traj_b_edge(3,Nobs)+1-b_corner(3,Nobs));


%now we calculate the heading of the trajectory in radians
for t=1:size(traj,2)-1
    slope = (traj(2,t)-traj(2,t+1))  / (traj(1,t)-traj(1,t+1));
    theta_traj(t+1) = atan(slope);
    if theta_traj(t+1)<0
        theta_traj(t+1)=theta_traj(t+1)+pi;
    end
        
end
theta_traj(1)=theta_traj(2);

end
