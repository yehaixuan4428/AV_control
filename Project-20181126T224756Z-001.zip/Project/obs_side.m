function [ind_l, ind_r] = obs_side(Nobs,Xobs_ctr,TestTrack)
% find three close points on centerline to obstacle center
ctr_close_ind=dsearchn(TestTrack.cline',Xobs_ctr);
for i=1:size(ctr_close_ind)
    ctr_close_loc(:,3*i-2:3*i) = TestTrack.cline(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

%find three close points on left track boundary
bl_close_ind=dsearchn(TestTrack.bl',Xobs_ctr);
for i=1:size(ctr_close_ind)
    bl_close_loc(:,3*i-2:3*i) = TestTrack.bl(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

% check if obstacle lies inside of a box formed by left boundary and
% centerine
is_left=zeros(Nobs,1);
for i=1:Nobs
    pgonx = [ctr_close_loc(:,3*i-2:3*i) bl_close_loc(:,3*i-2:3*i);];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left(i)=inpolygon(Xobs_ctr(i,1),Xobs_ctr(i,2),pgonx(1,k)',pgonx(2,k)');

end

%save left and right obstacles in seperate arrays
 ind_l = find(is_left(:)==1);
 ind_r = find(is_left(:)==0);
end