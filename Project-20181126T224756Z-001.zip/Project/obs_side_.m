%clean up
clc
clear all

load TestTrack
Nobs=25;

path = gen_traj(Nobs,TestTrack);


%%plot course with obstables
%plot left boundary of track
plot(TestTrack.bl(1,:),TestTrack.bl(2,:))

% %plot right boundary of track
hold on
plot(TestTrack.br(1,:),TestTrack.br(2,:))

%plot trajectory
hold on
plot(path(1,:),path(2,:), 'g','MarkerSize', 10)

function [traj] = gen_traj(Nobs,TestTrack)
%populate random obstacles
Xobs= generateRandomObstacles(Nobs);
Xobs = cell2mat(Xobs);

%calculate obstacle centers and corners
for i = 1:Nobs
    Xobs_ctr(i,1) = mean(Xobs(:,2*i-1));
    Xobs_ctr(i,2) = mean(Xobs(:,2*i));
    Xobs_x(4*i-3:4*i,1) = Xobs(:,2*i-1);
    Xobs_y(4*i-3:4*i,1) = Xobs(:,2*i);
end

%see which side of track the obstacle is on
[ind_l, ind_r] = obs_side(Nobs,Xobs_ctr, TestTrack);

left_obs = Xobs_ctr(ind_l,:);
right_obs = Xobs_ctr(ind_r,:);



%get a line between left boundary and centerline
l_cline=(TestTrack.bl+TestTrack.cline)./2;

%get a line between right boundary and centerline
r_cline=(TestTrack.br+TestTrack.cline)./2;

%expand sampling rate of center line and test track boundary
scale = 50;
bl_x=interp(TestTrack.bl(1,:),scale);
bl_y=interp(TestTrack.bl(2,:),scale);
br_x=interp(TestTrack.br(1,:),scale);
br_y=interp(TestTrack.br(2,:),scale);
cline_x=interp(TestTrack.cline(1,:),scale);
cline_y=interp(TestTrack.cline(2,:),scale);
rcline_y=interp(r_cline(2,:),scale);
rcline_x=interp(r_cline(1,:),scale);
lcline_y=interp(l_cline(2,:),scale);
lcline_x=interp(l_cline(1,:),scale);
r_cline=[rcline_x ;rcline_y];
l_cline=[lcline_x ;lcline_y];

%lets make convexhull of obstacles and check if centerline goes through it
is_coll=zeros(size(cline_x,2),25);
is_coll_obs=zeros(size(cline_x,2),25);
for i=1:Nobs
    pgonx = 1.3*[Xobs(:,2*i-1)-mean(Xobs(:,2*i-1)) Xobs(:,2*i)-mean(Xobs(:,2*i))];
    pgonx=[pgonx(:,1)+mean(Xobs(:,2*i-1)) pgonx(:,2)+mean(Xobs(:,2*i))];
    k=convhull(pgonx(:,1),pgonx(:,2));
    for j =1:size(cline_x,2)
        is_coll(j,i)=inpolygon(cline_x(j),cline_y(j),pgonx(k,1),pgonx(k,2));
        if is_coll(j,i)
            is_coll_obs(j,i) = i;
        end
        
    end

    plot(pgonx(k,1),pgonx(k,2),'LineWidth',2)
    hold on
end
is_coll_all=sum(is_coll,2);
is_coll_obs_all=sum(is_coll_obs,2);



%save collision vs good pts in seperate arrays
%  ind_c = find(is_coll_all(:)==1);
%  ind_not = find(is_coll_all(:)==0);
% coll_obs = [cline_x(ind_c); cline_y(ind_c)];
% ncoll_obs = [cline_x(ind_not); cline_y(ind_not)];

%now replace colliding centerline points with a new center line on open
%track side
traj=[cline_x;cline_y];
side = zeros(1,size(cline_x,2));
for i=1:size(is_coll_obs_all,1)
    if ismember(is_coll_obs_all(i),ind_l)
        traj(:,i) = r_cline(:,i);
        side(i) = 1;
    elseif ismember(is_coll_obs_all(i),ind_r)
        traj(:,i) = l_cline(:,i);
        side(i) = 2;
    end
end


%find loc corresponding to front of obs
f_corner = zeros(4,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i-1) ==0))
        f_corner(1:2,l) = traj(:,i);
        f_corner(3,l) = i;
        f_corner(4,l) = side(i);
        l=l+1;
    end
end

%find loc corresponding to back of obs
b_corner = zeros(3,Nobs);
l=1;
for i=10:size(is_coll_obs_all,1)
    if ((is_coll_all(i) ==1) && (is_coll_all(i+1) ==0))
        b_corner(1:2,l) = traj(:,i);
        b_corner(3,l) = i;
        b_corner(4,l) = side(i);
        l=l+1;
    end
end

%now we ramp into the front edge of the obstacle
traj_left_edge = zeros(3,Nobs);
for i=1:Nobs
    for j=1:f_corner(3,i)-1
        %compute distance of each point on traj to next obs
        dist = sqrt( (f_corner(1,i)-traj(1,j))^2 + (f_corner(2,i)-traj(2,j))^2 );
        if dist<=10.0
            traj_left_edge(:,i) = [traj(:,j);j];
            break;
        end
    end 

    traj(1,traj_left_edge(3,i):f_corner(3,i))=linspace(traj_left_edge(1,i), f_corner(1,i), -traj_left_edge(3,i)+1+f_corner(3,i));
    traj(2,traj_left_edge(3,i):f_corner(3,i))=linspace(traj_left_edge(2,i), f_corner(2,i), -traj_left_edge(3,i)+1+f_corner(3,i));
end


%now we ramp off the back edge of the obstacle
traj_b_edge = zeros(3,Nobs);
for i=1:Nobs
    for j=size(traj,2)-1:-1:b_corner(3,i)+1
        
        %compute distance of each point on traj to next obs
        dist = sqrt( (b_corner(1,i)-traj(1,j))^2 + (b_corner(2,i)-traj(2,j))^2 );
   
        if dist<=10.0
            traj_b_edge(:,i) = [traj(:,j);j];
            break;
        end
    end 
    
    traj(1,b_corner(3,i):traj_b_edge(3,i))=linspace(b_corner(1,i),traj_b_edge(1,i), traj_b_edge(3,i)+1-b_corner(3,i));
    traj(2,b_corner(3,i):traj_b_edge(3,i))=linspace(b_corner(2,i),traj_b_edge(2,i), traj_b_edge(3,i)+1-b_corner(3,i));
end

%smoothing to stay on same side of track if consecutive objects are on same 
%side of track
for i =1:Nobs-1
    %check if the next obstacle is on the same side of the track
    if (b_corner(4,i) == f_corner(4,i+1))
        if(b_corner(4,i) == 1) 
            traj(1,b_corner(3,i):f_corner(3,i+1))= r_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= r_cline(2,b_corner(3,i):f_corner(3,i+1));
        else
            traj(1,b_corner(3,i):f_corner(3,i+1))= l_cline(1,b_corner(3,i):f_corner(3,i+1));
            traj(2,b_corner(3,i):f_corner(3,i+1))= l_cline(2,b_corner(3,i):f_corner(3,i+1));
        end
    end
end

% %plot track centerline collisions
% hold on
% plot(coll_obs(1,:),coll_obs(2,:), '.r','MarkerSize', 10)
% 
% %plot track centerline non collisions
% hold on
% plot(ncoll_obs(1,:),ncoll_obs(2,:), '.g','MarkerSize', 10)

%plot center of mass of random obstacles
%hold on
%plot(Xobs_ctr(:,1),Xobs_ctr(:,2),'.m')

%plot obstacles center on the left side
hold on
plot(left_obs(:,1),left_obs(:,2),'.m','MarkerSize', 10)

%plot obstacles center on the right side
hold on
plot(right_obs(:,1),right_obs(:,2),'.c','MarkerSize', 10)

%plot random obstacle edges
hold on
plot(Xobs_x(:,1),Xobs_y(:,1),'.b')
% hold off

% %plot left centerline
% hold on
% plot(cline_x,cline_y,'.b')
% 
% %plot right centerline
% hold on
% plot(r_cline(1,:),r_cline(2,:),'*b')

% %plot obstacle center vs centerline
% hold on
% plot(ctr_close_loc(1,:),ctr_close_loc(2,:),'.b')
% 
% %plot obstacle center vs left boundary
% hold on
% plot(bl_close_loc(1,:),bl_close_loc(2,:),'.b')

end



function [ind_l, ind_r] = obs_side(Nobs,Xobs_ctr,TestTrack)

% find three close points on centerline to obstacle center
ctr_close_ind=dsearchn(TestTrack.cline',Xobs_ctr);
for i=1:size(ctr_close_ind)
    ctr_close_loc(:,3*i-2:3*i) = TestTrack.cline(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

%find three close points on left track boundary
bl_close_ind=dsearchn(TestTrack.bl',Xobs_ctr);
for i=1:size(ctr_close_ind)
    bl_close_loc(:,3*i-2:3*i) = TestTrack.bl(:,ctr_close_ind(i)-1:ctr_close_ind(i)+1);
end

% check if obstacle lies inside of a box formed by left boundary and
% centerine
is_left=zeros(Nobs,1);
for i=1:Nobs
    pgonx = [ctr_close_loc(:,3*i-2:3*i) bl_close_loc(:,3*i-2:3*i);];
    k=convhull(pgonx(1,:)',pgonx(2,:)');
    is_left(i)=inpolygon(Xobs_ctr(i,1),Xobs_ctr(i,2),pgonx(1,k)',pgonx(2,k)');
    %plot(pgonx(1,k)',pgonx(2,k)','LineWidth',2)
    %hold on
end

%save left and right obstacles in seperate arrays
 ind_l = find(is_left(:)==1);
 ind_r = find(is_left(:)==0);
end