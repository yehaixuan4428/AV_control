function [a,b] = pt2line([x1,x2],[y1,y2],magic)
% magic = 0 means left, magic = 1 means right
if abs(x1-x2) < 0.001
    a = 1
    if magic == 0
        b = min([x1,x2];
    else
        b = max([x1,x2];
    end
else
    coeff = polyfit([ob(1,1),ob(2,1)],[ob(1,2),ob(2,2)],1);
    a = coeff(1);
    b = coeff(2);
end