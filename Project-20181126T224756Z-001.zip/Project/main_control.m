%% Model
deltaf_ub = 0.5;
deltaf_lb = -0.5;
Fx_ub = 6000;
Fx_lb = -10000;
m = 1400;
W = 13720;
Nw = 2;
f = 0.01;
Iz = 2667;
a = 1.35;
b = 1.45;
By = 0.27;
Cy = 1.2;
Dy = 2921;
Ey = -1.6;
Shy = 0;
Svy = 0;


% dx = car_model(state,input)
load TestTrack.mat
track_lb = TestTrack.bl;
track_rb = TestTrack.br;
track_c = TestTrack.cline;
track_theta = TestTrack.theta;
x_c = track_c(1,:);y_c = track_c(2,:);

figure;hold on;
plot(track_lb(1,:),track_lb(2,:),'k');
plot(track_rb(1,:),track_rb(2,:),'k');
plot(track_c(1,:),track_c(2,:),'r--');
hold off;grid on;axis equal;

x0 = [287;5;-176;0;2;0];
n = 501;
input = zeros(2,n);
input(2,:)=5000;
%%
n = 701;
traj = zeros(6,n);
traj(:,1) = x0;

figure;hold on;
plot(track_lb(1,:),track_lb(2,:),'k');
plot(track_rb(1,:),track_rb(2,:),'k');
plot(track_c(1,:),track_c(2,:),'r--');
plot(traj(1,1),traj(3,1),'b.','linewidth',10);
grid on;axis equal;
for i = 2:n
    dx = car_model(traj(:,i-1),input(:,i));
    traj(:,i) = traj(:,i-1)+0.01*dx;
    plot(traj(1,i),traj(3,i),'g.');
%     pause(0.1)
end
% % figure;hold on;
% plot(track_lb(1,:),track_lb(2,:),'k');
% plot(track_rb(1,:),track_rb(2,:),'k');
% plot(track_c(1,:),track_c(2,:),'r--');
% plot(traj(1,1),traj(3,1),'b.','linewidth',10);
% plot(traj(1,:),traj(3,:),'g');
% hold off;grid on;axis equal;

%%
%constants
close all;
W=13720;
Nw=2;
f=0.01;
Iz=2667;
a=1.35;
b=1.45;
By=0.27;
Cy=1.2;
Dy=2921;
Ey=-1.6;
Shy=0;
Svy=0;
m=1400;



u_nom = 5;
x0 = [287;5;-176;0;2;0];
load TestTrack.mat
dist = [0,sqrt(diff(y_c).^2+diff(x_c).^2)];

tstep = round(dist./u_nom.*100);
N = sum(tstep);

K_deltaf = 0.275;
K_Fx = 900;
traj = x0';
input = [];
kkk=246;
for i = 2:kkk
    psi_current = traj(end,5);
    psi_desired = track_theta(i);
    psi_diff = psi_desired-psi_current;
    deltaf = K_deltaf * psi_diff;
    if deltaf > 0.5
        deltaf = 0.5;
    end
    if deltaf < -0.5
        deltaf = -0.5;
    end
    
    u_current = traj(end,2);
    u_desired = u_nom;
    u_diff = u_desired-u_current;
    Fx = K_Fx * u_diff;
    if Fx > 500
        Fx = 500;
    end
    if Fx < 0
        Fx = 0;
    end
    
    
    nn = tstep(i);
    if i>2
        nn = nn+1;
    end
    input_add = [deltaf*ones(nn,1),Fx*ones(nn,1)];
    
    T=0:0.01:(nn-1)*0.01;
    
    %slip angle functions in degrees
    a_f=@(t,x) rad2deg(deltaf-atan2(x(4)+a*x(6),x(2)));
    a_r=@(t,x) rad2deg(-atan2((x(4)-b*x(6)),x(2)));

    %Nonlinear Tire Dynamics
    phi_yf=@(t,x) (1-Ey)*(a_f(t,x)+Shy)+(Ey/By)*atan(By*(a_f(t,x)+Shy));
    phi_yr=@(t,x) (1-Ey)*(a_r(t,x)+Shy)+(Ey/By)*atan(By*(a_r(t,x)+Shy));

    F_yf=@(t,x) Dy*sin(Cy*atan(By*phi_yf(t,x)))+Svy;
    F_yr=@(t,x) Dy*sin(Cy*atan(By*phi_yr(t,x)))+Svy;

    %vehicle dynamics
    df=@(t,x) [x(2)*cos(x(5))-x(4)*sin(x(5));...
            (-f*W+Nw*Fx-F_yf(t,x)*sin(deltaf))/m+x(4)*x(6);...
            x(2)*sin(x(5))+x(4)*cos(x(5));...
            (F_yf(t,x)*cos(deltaf)+F_yr(t,x))/m-x(2)*x(6);...
            x(6);...
            (F_yf(t,x)*a*cos(deltaf)-F_yr(t,x)*b)/Iz];
      
    %Solve for trajectory      
    [~,traj_add]=ode45(df,T,traj(end,:));
    traj = [traj;traj_add(2:end,:)];
    input =[input;input_add(2:end,:)];
end

nnn = sum(tstep(2:kkk));
TT = 0:0.01:(nnn-1)*0.01;
figure;plot(TT,traj(:,2));title('u')
figure;plot(traj(:,1),traj(:,3));
hold on;plot(x_c(1:kkk),y_c(1:kkk));
plot(track_lb(1,1:kkk),track_lb(2,1:kkk),'k--');
plot(track_rb(1,1:kkk),track_rb(2,1:kkk),'k--');
legend('traj','cline','bound','bound');axis equal;

%%
input_end = [-0.05*ones(200,1),3000*ones(200,1)];
input_new = [input;input_end];
[Y]=forwardIntegrateControlInput(input_new,x0); 

figure;plot(Y(:,1),Y(:,3));
hold on;plot(x_c,y_c);
plot(track_lb(1,:),track_lb(2,:),'k--');
plot(track_rb(1,:),track_rb(2,:),'k--');
legend('traj','cline','bound','bound');axis equal;



magicnumber=37873;
figure;plot(Y(1:magicnumber,1),Y(1:magicnumber,3));
hold on;plot(x_c,y_c);
plot(track_lb(1,:),track_lb(2,:),'k--');
plot(track_rb(1,:),track_rb(2,:),'k--');
legend('traj','cline','bound','bound');axis equal;

%% Shortening the input
load TestTrack.mat
% load input_PControl.mat
x0 = [287;5;-176;0;2;0];
track_lb = TestTrack.bl;
track_rb = TestTrack.br;
track_c = TestTrack.cline;
track_theta = TestTrack.theta;
x_c = track_c(1,:);y_c = track_c(2,:);
%%
x0 = [287;5;-176;0;2;0];
magic = 8071;
[Y]=forwardIntegrateControlInput(input_mod(1:magic,:),x0); 
figure;plot(Y(:,1),Y(:,3));
hold on;plot(x_c,y_c,'b-*');
plot(track_lb(1,:),track_lb(2,:),'k--');
plot(track_rb(1,:),track_rb(2,:),'k--');
legend('traj','cline','bound','bound');axis equal;

figure;plot(Y(:,2))  

checkTrajectory(Y(1:8071,:),input_mod(1:8071,:))

